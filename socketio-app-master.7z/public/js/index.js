var socket = io();
var selectRoomElement= jQuery('#active-rooms');
socket.on('connect', function() {
	socket.emit('getAllActiveRooms');
});

socket.on('updateActiveRooms', function(activeRooms){
	console.log('activeRooms', activeRooms);
	
	selectRoomElement.empty();
	var defaultOption = jQuery('<option disabled selected></option>').attr("value", "default").text("Please select a room");
	selectRoomElement.append(defaultOption);
	for (var roomObj in activeRooms){
		var option= jQuery('<option></option>').attr("value", roomObj).text(`${roomObj} : ${activeRooms[roomObj]} active user(s)`);
		selectRoomElement.append(option);
	};
});

selectRoomElement.change(function(){
	var selectedOption= jQuery("#active-rooms option:selected").text();
	var room= selectedOption.split(':')[0].trim();
	jQuery('[name=room]').val(room);
});
